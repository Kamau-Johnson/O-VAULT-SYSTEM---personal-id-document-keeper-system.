<?php
// Handle the feedback form submission
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $user_name = htmlspecialchars($_POST['user_name']);
    $user_email = htmlspecialchars($_POST['user_email']);
    $message = htmlspecialchars($_POST['message']);

    // Database connection
    include 'db_conn.php';

    // Insert the feedback into the database
    $stmt = $conn->prepare("INSERT INTO feedback (user_name, user_email, message) VALUES (?, ?, ?)");
    $stmt->bind_param("sss", $user_name, $user_email, $message);

    if ($stmt->execute()) {
        $feedbackMessage = "Your feedback has been submitted successfully!";
    } else {
        $feedbackMessage = "Error: " . $stmt->error;
    }

    $stmt->close();
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Feedback</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        /* Basic Reset */
        * {
            box-sizing: border-box;
            margin: 0;
            padding: 0;
        }

        /* Body Styling */
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-image: url('FeedbackBackground.webp'); /* Replace with your background image */
            background-size: cover;
            background-position: center;
            background-attachment: fixed;
            color: #fff;
            margin: 0;
            padding: 0;
        }

        .overlay {
            background: rgba(0, 0, 0, 0.7);
            min-height: 100vh;
            padding: 50px 20px;
        }

        .container {
            max-width: 900px;
            margin: 0 auto;
        }

        .contact-wrapper {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 30px;
            margin-top: 50px;
            width: 100%;
            margin-left: auto;
            margin-right: auto;
        }

        .contact-info,
        .contact-form {
            padding: 30px;
            background: rgba(255, 255, 255, 0.1);
            border-radius: 15px;
            backdrop-filter: blur(10px);
        }

        h1 {
            font-size: 2.5em;
            margin-bottom: 20px;
            text-align: center;
        }

        .form-group {
            margin-bottom: 20px;
        }

        input,
        textarea {
            width: 100%;
            padding: 12px;
            border: none;
            background: rgba(255, 255, 255, 0.1);
            border-radius: 5px;
            color: #fff;
            margin-top: 5px;
        }

        textarea {
            height: 150px;
            resize: vertical;
        }

        button {
            background: #2196F3;
            color: #fff;
            padding: 12px 30px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 16px;
            transition: background 0.3s;
        }

        button:hover {
            background: #1976D2;
        }

        .success-message {
            background: rgba(76, 175, 80, 0.3);
            padding: 15px;
            border-radius: 5px;
            margin-bottom: 20px;
        }

        .error-message {
            background: rgba(255, 0, 0, 0.3);
            padding: 15px;
            border-radius: 5px;
            margin-bottom: 20px;
        }

        .btn-back {
            display: inline-block;
            margin-top: 20px;
            text-decoration: none;
            padding: 12px 18px;
            background: #28a745;
            color: white;
            border-radius: 5px;
            font-size: 16px;
            text-align: center;
            width: auto;
        }

        .btn-back:hover {
            background: #218838;
        }

        .btn-back:focus {
            outline: none;
        }

        @media (max-width: 768px) {
            .contact-wrapper {
                grid-template-columns: 1fr;
            }
        }
    </style>
</head>

<body>
    <div class="overlay">
        <div class="container">
            <div class="header">
                <h1>Feedback Poll</h1>
            </div>

            <form action="feedback.php" method="POST">
                <div class="contact-form">
                    <div class="form-group">
                        <label for="user_name">Your Name</label>
                        <input type="text" id="user_name" name="user_name" required>
                    </div>

                    <div class="form-group">
                        <label for="user_email">Your Email</label>
                        <input type="email" id="user_email" name="user_email" required>
                    </div>

                    <div class="form-group">
                        <label for="message">Your Message</label>
                        <textarea id="message" name="message" required></textarea>
                    </div>

                    <button type="submit">Submit Feedback</button>
                </div>
            </form>

            <?php if (isset($feedbackMessage)): ?>
                <div class="success-message">
                    <p><?php echo $feedbackMessage; ?></p>
                </div>
            <?php endif; ?>

            <a href="index.php" class="btn-back">Back to Home</a>
        </div>
    </div>
</body>

</html>
