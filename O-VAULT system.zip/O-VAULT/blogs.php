<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Blog Section</title>
    <link href="https://fonts.googleapis.com/css2?family=Oswald:wght@400;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="blogs.css">
    <link rel="stylesheet" href="icon.svg">
</head>

<style>
/* Basic Reset */
        * {
            box-sizing: border-box;
            margin: 0;
            padding: 0;
        }

        /* Body Styling */
        body {
            font-family: 'Poppins', sans-serif;
            background: url('backgroundblog1.webp') no-repeat center center fixed;
            background-size: cover;
            margin: 0;
            padding: 0;
            color: #333;
        }

        /* Blog Section */
        #blog {
            display: flex;
            flex-direction: column;
            align-items: center;
            padding: 40px;
        }

        /* Blog Heading */
        .blog-heading h3 {
            font-size: 3.5rem;
            font-weight: 700;
            color: #2b2b2b;
            letter-spacing: 1.5px;
            text-transform: uppercase;
            font-family: 'Montserrat', sans-serif;
            margin-top: 20px;
        }

        .blog-heading {
            text-align: center;
        }

        .blog-heading span {
            color: #f33c3c;
        }

        /* Blog Container */
        .blog-container {
            display: flex;
            flex-wrap: wrap;
            justify-content: center;
            gap: 20px;
        }

        /* Blog Box */
        .blog-box {
            width: 350px;
            background-color: #ffffff;
            border: 1px solid #ececec;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
            border-radius: 8px;
            transition: transform 0.2s;
        }

        .blog-box:hover {
            transform: scale(1.02);
        }

        /* Blog Image */
        .blog-img img {
            width: 100%;
            height: auto;
            border-top-left-radius: 8px;
            border-top-right-radius: 8px;
        }

        /* Blog Text */
        .blog-text {
            padding: 20px;
        }

        .blog-text span {
            display: block;
            color: #f33c3c;
            font-size: 0.9rem;
            margin-bottom: 10px;
        }

        .blog-title {
            font-size: 1.3rem;
            font-weight: 500;
            color: #272727;
            text-decoration: none;
        }

        .blog-title:hover {
            color: #c74242;
            transition: color 0.3s ease;
        }

        /* Change font for paragraph text */
        .blog-text p {
            font-family: 'Arial', sans-serif; /* You can change Arial to any font you prefer */
            color: #9b9b9b;
            font-size: 0.9rem;
            margin: 15px 0;
        }

        .blog-text a {
            color: #0f0f0f;
            text-decoration: none;
        }

        .blog-text a:hover {
            color: #c74242;
            transition: color 0.3s ease;
        }

        /* Responsive Design */
        @media (max-width: 768px) {
            .blog-box {
                width: 80%;
            }
        }
    .other-blogs-btn {
        position: absolute;
        top: 40px;
        right: 95px;
        padding: 10px 15px;
        width: auto;
        background-color: black;
        color: yellowgreen;
        border: none;
        border-radius: 5px;
        font-size: 14px;
        font-weight: bold;
        cursor: pointer; /* Change cursor to indicate the button is clickable */
        text-decoration: none; /* Remove underline */
        transition: background-color 0.25s;
        box-sizing: border-box;
    }

    .other-blogs-btn:hover {
        background-color: cyan;
        color: black;
    }

    /* Change font for paragraph text */
    .blog-text p {
        font-family: 'Arial', sans-serif;
        color: #9b9b9b;
        font-size: 0.9rem;
        margin: 15px 0;
    }

    /* Back Button Positioned on Left */
    .back-btn {
        position: absolute;
        top: 40px; /* Adjust the vertical position */
        left: 20px; /* Align the button to the left */
        padding: 10px 15px;
        width: auto;
        background-color: black;
        color: yellowgreen;
        border: none;
        border-radius: 5px;
        font-size: 14px;
        font-weight: bold;
        cursor: pointer; /* Change cursor to indicate the button is clickable */
        text-decoration: none; /* Remove underline */
        transition: background-color 0.25s;
        box-sizing: border-box;
    }

    .back-btn:hover {
        background-color: cyan;
        color: black;
    }
</style>

<body>
    <!-- Anchor tag to make the button clickable -->
    <a href="Other Blogs.php" class="other-blogs-btn">
        Other Blogs
    </a>
    <!-- Back Button Positioned on Left -->
    <a href="home.php" class="back-btn">
        Back
    </a>

    <section id="blog">
        <div class="blog-heading">
            <span>My Recent Posts</span>
            <h3>My Blogs</h3>
        </div>

        <div class="blog-container">
            <!-- Blog 1 -->
            <div class="blog-box">
                <div class="blog-img">
                    <img alt="blog" src="blog1.webp">
                </div>
                <div class="blog-text">
                    <span>19th February 2020 / ID & Document Keeper System</span>
                    <a href="#" class="blog-title">Navigating Global Issues Through Document Management Evolution</a>
                    <p>The website ID & Secure Document News provides insights into the evolution of secure identity and document management systems, highlighting global issues and solutions.</p>
                    <a href="https://securedocumentnews.com/about/" target="_blank">Read More</a>
                </div>
            </div>

            <!-- Blog 2 -->
            <div class="blog-box">
                <div class="blog-img">
                    <img alt="blog" src="Blog3.webp">
                </div>
                <div class="blog-text">
                    <span>18th July 2021 / ID & Document Keeper System</span>
                    <a href="#" class="blog-title">Exploring Document Security Challenges in Digital Transformation</a>
                    <p>Multimedia Tools and Applications discusses the evolving challenges in document verification and authentication, focusing on biometrics and digital security technologies for enhanced documentation processes.</p>
                    <a href="https://link.springer.com/article/10.1007/s11042-020-10061-x" target="_blank">Read More</a>
                </div>
            </div>

            <!-- Blog 3 -->
            <div class="blog-box">
                <div class="blog-img">
                    <img alt="blog" src="Blog2.webp">
                </div>
                <div class="blog-text">
                    <span>12th August 2024 / ID and Document Keeper System</span>
                    <a href="#" class="blog-title">Document Validation: The AI Advantage You Can't Ignore?</a>
                    <p>The NineID blog highlights the significance of document validation software, showcasing AI-driven systems that improve verification processes and boost accuracy in security.</p>
                    <a href="https://www.nineid.com/blog/document-validation-software" target="_blank">Read More</a>
                </div>
            </div>
        </div>
    </section>
</body>

</html>
