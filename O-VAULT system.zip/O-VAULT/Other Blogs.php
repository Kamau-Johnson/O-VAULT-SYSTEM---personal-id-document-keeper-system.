<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Blog Section</title>
    <link href="https://fonts.googleapis.com/css2?family=Oswald:wght@400;700&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Poppins&display=swap" rel="stylesheet">
    <style>
        /* Basic Reset */
        * {
            box-sizing: border-box;
            margin: 0;
            padding: 0;
        }

        /* Body Styling */
        body {
            font-family: 'Poppins', sans-serif;
            background: url('backgroundblog1.webp') no-repeat center center fixed;
            background-size: cover;
            margin: 0;
            padding: 0;
            color: #333;
        }

        /* Blog Section */
        #blog {
            display: flex;
            flex-direction: column;
            align-items: center;
            padding: 40px;
        }

        /* Blog Heading */
        .blog-heading h3 {
            font-size: 3.5rem;
            font-weight: 700;
            color: #2b2b2b;
            letter-spacing: 1.5px;
            text-transform: uppercase;
            font-family: 'Montserrat', sans-serif;
            margin-top: 20px;
        }

        .blog-heading {
            text-align: center;
        }

        .blog-heading span {
            color: #f33c3c;
        }

        /* Blog Container */
        .blog-container {
            display: flex;
            flex-wrap: wrap;
            justify-content: center;
            gap: 20px;
        }

        /* Blog Box */
        .blog-box {
            width: 350px;
            background-color: #ffffff;
            border: 1px solid #ececec;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
            border-radius: 8px;
            transition: transform 0.2s;
        }

        .blog-box:hover {
            transform: scale(1.02);
        }

        /* Blog Image */
        .blog-img img {
            width: 100%;
            height: auto;
            border-top-left-radius: 8px;
            border-top-right-radius: 8px;
        }

        /* Blog Text */
        .blog-text {
            padding: 20px;
        }

        .blog-text span {
            display: block;
            color: #f33c3c;
            font-size: 0.9rem;
            margin-bottom: 10px;
        }

        .blog-title {
            font-size: 1.3rem;
            font-weight: 500;
            color: #272727;
            text-decoration: none;
        }

        .blog-title:hover {
            color: #c74242;
            transition: color 0.3s ease;
        }

        /* Change font for paragraph text */
        .blog-text p {
            font-family: 'Arial', sans-serif; /* You can change Arial to any font you prefer */
            color: #9b9b9b;
            font-size: 0.9rem;
            margin: 15px 0;
        }

        .blog-text a {
            color: #0f0f0f;
            text-decoration: none;
        }

        .blog-text a:hover {
            color: #c74242;
            transition: color 0.3s ease;
        }

        /* Responsive Design */
        @media (max-width: 768px) {
            .blog-box {
                width: 80%;
            }
        }

/* Back Button Positioned on Left */
    .back-btn {
        position: absolute;
        top: 40px; /* Adjust the vertical position */
        left: 20px; /* Align the button to the left */
        padding: 10px 15px;
        width: auto;
        background-color: black;
        color: yellowgreen;
        border: none;
        border-radius: 5px;
        font-size: 14px;
        font-weight: bold;
        cursor: pointer; /* Change cursor to indicate the button is clickable */
        text-decoration: none; /* Remove underline */
        transition: background-color 0.25s;
        box-sizing: border-box;
    }

    .back-btn:hover {
        background-color: cyan;
        color: black;
    }
    </style>
</head>

<body>
    <section id="blog">
        <div class="blog-heading">
            <span>My Recent Posts</span>
            <h3>Blogs</h3>
        </div>
    <!-- Back Button Positioned on Left -->
    <a href="blogs.php" class="back-btn">
        Back
    </a>
        <div class="blog-container">
            <!-- Blog 1 -->
            <div class="blog-box">
                <div class="blog-img">
                    <img alt="blog" src="blog4.webp">
                </div>
                <div class="blog-text">
                    <span>12th August 2024 / ID & Document Keeper System</span>
                    <a href="#" class="blog-title">The Evolution of Identity & Document Management: Global Challenges & Solutions</a>
                    <p>The website ID & Secure Document News explores the continuous advancements in secure identity and document management systems. It delves into the global challenges surrounding digital documentation and the solutions being implemented to address them. Through expert insights, the site highlights the growing need for robust identity verification methods in response to evolving threats and the shift towards digital transformation. These insights are crucial for organizations looking to strengthen their documentation processes and security measures in an increasingly interconnected world.</p>
                    <a href="https://www.nineid.com/blog/document-validation-software" target="_blank">Read More</a>
                </div>
            </div>

            <!-- Blog 2 -->
            <div class="blog-box">
                <div class="blog-img">
                    <img alt="blog" src="Blog5.webp">
                </div>
                <div class="blog-text">
                    <span>7th September 2021 / ID & Document Keeper System</span>
                    <a href="#" class="blog-title">Optimizing Document Management Systems: Insights from Ricoh USA</a>
                    <p>The website Ricoh USA provides in-depth resources on enhancing document management through digital transformation. It emphasizes the importance of secure data handling, compliance with regulatory standards, and efficient workflows. Ricoh’s solutions address global challenges in documentation, focusing on secure storage, automation, and AI-driven processes to streamline document management. By implementing these strategies, organizations can improve data security, optimize productivity, and reduce operational costs, making Ricoh a leader in the field of secure document solutions.</p>
                    <a href="https://www.ricoh-usa.com/en" target="_blank">Read More</a>
                </div>
            </div>

            <!-- Blog 3 -->
            <div class="blog-box">
                <div class="blog-img">
                    <img alt="blog" src="Blog6.webp">
                </div>
                <div class="blog-text">
                    <span>6th November 2024 / ID and Document Keeper System</span>
                    <a href="#" class="blog-title">Streamlining Digital Documentation with Folderit’s Solutions</a>
                    <p>The website Folderit offers a comprehensive electronic document management system (EDMS) that focuses on simplifying digital documentation for businesses of all sizes. With features like cloud-based storage, OCR content indexing, automated workflows, and access control, Folderit helps organizations maintain security and compliance while optimizing efficiency. The platform’s solutions are designed to streamline document storage, retrieval, and collaboration, making it an ideal choice for businesses looking to enhance their digital document management processes.</p>
                    <a href="https://www.folderit.com/" target="_blank">Read More</a>
                </div>
            </div>
        </div>
    </section>
</body>

</html>
