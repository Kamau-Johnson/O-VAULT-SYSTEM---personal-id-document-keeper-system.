<?php
session_start(); // Start the session

// Check if the user is not logged in, redirect to login page
if (!isset($_SESSION['user_name'])) {
    header("Location: index.php");
    exit();
}

// Capture the user's recent activity
if (!isset($_SESSION['recent_activity'])) {
    $_SESSION['recent_activity'] = [];
}

// Function to add new activity
function addActivity($activity) {
    // If there are more than 5 activities, remove the oldest one
    if (count($_SESSION['recent_activity']) >= 5) {
        array_shift($_SESSION['recent_activity']); // Remove oldest activity if more than 5
    }
    $_SESSION['recent_activity'][] = $activity;
}

// Example: Adding a sample activity whenever the page is accessed (you can replace this logic based on actual user actions)
addActivity("Accessed the Dashboard page");
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ID and Document Keeper System</title>
    <!-- Font Awesome CDN for padlock icon -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">

    <style>
        body {
            font-size: larger;
            font-family: Montserrat, sans-serif;
            font-weight: bolder;
            font-style: oblique;
            background-image: url('home.webp');
            background-size: 780px 600px;
            background-position: center;
            height: 100vh;
            background-color: yellowgreen;
            display: flex;
            flex-direction: column;
            justify-content: space-between;
            overflow-x: hidden; /* Prevent horizontal scrolling */
            margin: 0; /* Remove default margin */
            padding: 0; /* Remove default padding */
        }

        .navbar {
            position: absolute;
            top: 10px;
            right: 10px;
        }

        .navbar a {
            text-decoration: none;
            color: yellowgreen;
            background-color: black;
            padding: 8px 17px;
            margin: 0.2px;
            display: inline-block;
            border-radius: 5px;
            transition: background-color 0.25s;
        }

        .navbar a:hover {
            background-color: cyan;
        }

        .O-VAULTcontainer {
            display: flex;
            justify-content: center;
            align-items: center;
            height: 40%;
            width: 35.5%;
            overflow: hidden;
        }

        .title {
            font-size: 4em;
            color: #333;
            text-shadow: 2px 2px 4px rgba(0, 0, 0, 0.2);
            font-weight: bold;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }

        /* New message text split into two lines */
        .message-text {
            position: absolute;  /* Position the message relative to the nearest positioned ancestor */
            top: calc(12% + 100px);  /* Position it 100px below the O-VAULT title */
            left: 18.5%;             /* Center the message horizontally */
            transform: translateX(-50%); /* Adjust by 50% of its width to truly center it */
            font-size: 1.15em;
            font-weight: 835;
            text-align: center;
            color: black; 
            letter-spacing: 1px;
            padding: 10px;
        }

        .message-line-one {
            margin-bottom: 10px; /* Add space between the lines */
        }

        .message-line-two {
            margin-top: 10px;
        }

        .welcome {
            position: absolute;
            top: 94px;
            right: 42px;
            opacity: 0;
            transform: translateY(-20px);
            animation: pop-in 0.5s forwards;
            background-color: rgba(255, 255, 255, 0.8);
            border-radius: 10px;
            padding: 15px 5px;
            box-shadow: 0 2px 6px rgba(0, 0, 0, 0.2);
            width: 250px;
            text-align: center;
            white-space: nowrap;
            overflow: hidden;
            text-overflow: ellipsis;
        }

        .user-name {
            position: absolute;
            top: 272px;
            right: 42px;
            opacity: 0;
            transform: translateY(-20px);
            animation: pop-in 0.5s forwards;
            background-color: rgba(255, 255, 255, 0.8);
            border-radius: 10px;
            padding: 15px 5px;
            box-shadow: 0 2px 6px rgba(0, 0, 0, 0.2);
            width: 250px;
            text-align: center;
            white-space: nowrap;
            overflow: hidden;
            text-overflow: ellipsis;
        }

        @keyframes pop-in {
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        .welcome p, .user-name p {
            font-size: 1.35em;
            color: #333;
            margin: 0;
            line-height: 1.2;
        }

        .profile-section {
            position: absolute;
            top: 145px;
            right: 180px;
            width: auto;
            max-width: 300px;
            padding: 20px;
            border-radius: 10px;
            text-align: center;
        }

        .profile-pic {
            width: 95px;
            height: 95px;
            border-radius: 50%;
            overflow: hidden;
            margin-bottom: 10px;
            cursor: pointer;
            border: 2px solid #007bff;
        }

        .profile-pic img {
            width: 100%;
            height: 100%;
            object-fit: cover;
        }

        .padlock-container {
            display: flex;
            align-items: center;
            position: absolute;
            top: 385px; /* Position under username */
            left: 1120px;
            width: 100%;
        }

        .padlock-icon {
            font-size: 80px; /* Increase size of padlock */
            color: black;
            text-shadow: 2px 2px 4px rgba(0, 0, 0, 0.2); /* Optional shadow */
        }

        .recent-activity-box {
            position: absolute;
            top: 225px;
            left: 165px;
            width: 250px;
            background-color: black;
            border-radius: 10px;
            padding: 15px;
            box-shadow: 0 2px 6px rgba(0, 0, 0, 0.2);
            max-height: 250px;
            overflow-y: auto;
        }

        .recent-activity-box h3 {
            font-size: 1.3em;
            color: whitesmoke;
            text-align: center;
            margin-bottom: 10px;
        }

        .activity-item {
            font-size: 1.1em;
            color: white;
            margin-bottom: 10px;
        }

        footer {
            color: black;
            text-align: center;
            width: 100%;
            font-size: 1.0em;
            position: fixed;
            bottom: 0; /* Fix footer to the bottom */
            left: 0;
        }

        footer p {
            margin: 0;
        }

    </style>
</head>

<body>
    <div class="navbar">
        <a href="dashboard.php">Dashboard</a>
        <a href="about.php">About</a>
        <a href="blogs.php">Blogs</a>
        <a href="contact.php">Contact Us</a>
        <a href="logout.php">Logout</a>
    </div>

    <div class="O-VAULTcontainer">
        <h1 class="title">O-VAULT</h1>
    </div>

    <!-- Split message into two parts -->
    <div class="message-text">
        <div class="message-line-two">O-VAULT: Future secured.</div>
    </div>

    <!-- Welcome Layer -->
    <div class="welcome">
        <p>Welcome</p>
    </div>

    <!-- Name Layer -->
    <div class="user-name">
        <p><?php echo $_SESSION['name']; ?></p>
    </div>

    <!-- Padlock Icon Section -->
    <div class="padlock-container">
        <i class="fas fa-lock padlock-icon"></i> <!-- Font Awesome Padlock Icon -->
    </div>

    <!-- Profile Section -->
    <div class="profile-section">
        <div class="profile-pic">
            <img id="output" src="get_profile_pic.php?user_id=<?php echo $_SESSION['id']; ?>" alt="" />
        </div>
    </div>

    <!-- Footer Section -->
    <footer>
        <p>&copy; 2024 O-VAULT. All rights reserved.</p>
    </footer>
</body>

</html>
