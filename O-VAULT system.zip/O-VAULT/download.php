<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "test_db";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if (isset($_GET['table']) && isset($_GET['id'])) {
    $table = $_GET['table'];
    $id = $_GET['id'];

    $sql = "SELECT * FROM $table WHERE id='$id'";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            if ($table == 'ids') {
                $file = $row["id_image"];
                $filename = $row["id_name"];
                $fileType = strtolower(pathinfo($filename, PATHINFO_EXTENSION));
            } else {
                $file = $row["document"];
                $filename = $row["document_name"];
                $fileType = strtolower(pathinfo($filename, PATHINFO_EXTENSION));
            }

            switch ($fileType) {
                case 'jpg':
                case 'jpeg':
                    $mimeType = 'image/jpeg';
                    break;
                case 'png':
                    $mimeType = 'image/png';
                    break;
                case 'pdf':
                    $mimeType = 'application/pdf';
                    break;
                case 'xlsx':
                    $mimeType = 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet';
                    break;
                default:
                    $mimeType = 'application/octet-stream';
                    break;
            }

            header('Content-Type: ' . $mimeType);
            header("Content-Disposition: attachment; filename=\"$filename.$fileType\"");
            echo $file;
        }
    } else {
        echo "No results found";
    }
} 
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document Download</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f5f5f5;
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
            margin: 0;
        }

        .wrapper {
            width: 80%;
            max-width: 1000px;
            margin: 20px;
            display: flex;
            flex-direction: column;
            gap: 30px;
            background-color: white;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0px 4px 10px rgba(0, 0, 0, 0.1);
        }

        h2 {
            color: #4CAF50;
            text-align: center;
            margin-bottom: 20px;
        }

        .results h3 {
            color: #333;
            margin-bottom: 10px;
        }

        .results p {
            margin: 5px 0;
        }

        .results a {
            text-decoration: none;
            color: #4CAF50;
            font-weight: bold;
        }

        .results a:hover {
            color: #45a049;
        }

        .no-results {
            color: #888;
            text-align: center;
        }

        .download-link {
            margin-top: 20px;
            text-align: center;
        }

        .download-link a {
            padding: 10px 20px;
            background-color: #4CAF50;
            color: white;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            text-decoration: none;
        }

        .download-link a:hover {
            background-color: #45a049;
        }

    </style>
</head>

<body>

    <div class="wrapper">
        <h2>Document Information</h2>
        <div class="results">
            <?php
            // Code to fetch and display the results
            if (isset($_GET['table']) && isset($_GET['id'])) {
                $table = $_GET['table'];
                $id = $_GET['id'];

                $sql = "SELECT * FROM $table WHERE id='$id'";
                $result = $conn->query($sql);

                if ($result->num_rows > 0) {
                    while ($row = $result->fetch_assoc()) {
                        if ($table == 'ids') {
                            echo "<h3>ID Document: " . $row["id_name"] . "</h3>";
                            echo "<p>File Type: " . strtolower(pathinfo($row["id_name"], PATHINFO_EXTENSION)) . "</p>";
                        } else {
                            echo "<h3>Document: " . $row["document_name"] . "</h3>";
                            echo "<p>File Type: " . strtolower(pathinfo($row["document_name"], PATHINFO_EXTENSION)) . "</p>";
                        }
                    }
                } else {
                    echo "<p class='no-results'>No results found for this document.</p>";
                }
            }
            ?>
        </div>

        <div class="download-link">
            <?php
            if (isset($_GET['table']) && isset($_GET['id'])) {
                echo "<a href='?table=" . $_GET['table'] . "&id=" . $_GET['id'] . "'>Download File</a>";
            }
            ?>
        </div>
    </div>

</body>

</html>
