<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "test_db";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$idUploadMessage = "";
$docUploadMessage = "";

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (isset($_POST['upload_id'])) {
        $id_name = $_POST['idName'];
        $idFile = $_FILES['idFile']['tmp_name'];
        $imageFileType = strtolower(pathinfo($_FILES['idFile']['name'], PATHINFO_EXTENSION));

        // Check if file is an actual image
        $check = getimagesize($idFile);
        if ($check !== false && ($imageFileType == 'jpg' || $imageFileType == 'jpeg' || $imageFileType == 'png')) {
            $id_image = file_get_contents($idFile); // Get file content as binary

            // Use a prepared statement to insert the data
            $stmt = $conn->prepare("INSERT INTO ids (id_name, id_image) VALUES (?, ?)");
            $stmt->bind_param("ss", $id_name, $id_image);  // "ss" means both are strings (id_name is a string, id_image is binary data as a string)
            
            if ($stmt->execute()) {
                $idUploadMessage = "ID Uploaded Successfully";
            } else {
                $idUploadMessage = "Error: " . $stmt->error;
            }
            $stmt->close();  // Close statement after execution
        } else {
            $idUploadMessage = "WRONG FILE";
        }
    } elseif (isset($_POST['upload_doc'])) {
        $document_name = $_POST['docName'];
        $docFile = $_FILES['docFile']['tmp_name'];
        $docFileType = strtolower(pathinfo($_FILES['docFile']['name'], PATHINFO_EXTENSION));

        // Check if file is a PDF
        if ($docFileType == 'pdf') {
            // Get file content as binary
            $document = file_get_contents($docFile);

            // Use a prepared statement to insert the document data
            $stmt = $conn->prepare("INSERT INTO documents (document_name, document) VALUES (?, ?)");
            
            // Check for potential errors when binding and inserting data
            if ($stmt === false) {
                die("Error preparing statement: " . $conn->error);
            }

            // Use 's' for the document name (string) and 'b' for the binary document data
            $stmt->bind_param("sb", $document_name, $document);  // 'sb' means document_name is a string, document is binary data (long binary data)

            if ($stmt->execute()) {
                $docUploadMessage = "Document Uploaded Successfully";
            } else {
                $docUploadMessage = "Error: " . $stmt->error;
            }
            $stmt->close();  // Close statement after execution
        } else {
            $docUploadMessage = "WRONG FILE TYPE, ONLY PDF ALLOWED";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Upload & Retrieve System</title>
    <style>
        /* Global Styling */
        body {
            font-family: Arial, sans-serif;
            background-color: #f5f5f5;
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
            margin: 0;
        }

        .wrapper {
            width: 80%;
            max-width: 1000px;
            margin: 20px;
            display: flex;
            flex-direction: column;
            gap: 30px;
        }

        /* Upload Section Styling */
        .upload-container {
            display: flex;
            justify-content: space-between;
            gap: 20px;
        }

        .upload-section {
            flex: 1;
            background-color: #ffffff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0px 4px 10px rgba(0, 0, 0, 0.1);
        }

        .upload-section h2 {
            color: #4CAF50;
            margin-bottom: 15px;
            text-align: center;
        }

        label {
            display: block;
            margin-top: 10px;
            font-weight: bold;
        }

        input[type="file"],
        input[type="text"] {
            width: 100%;
            padding: 8px;
            margin-top: 5px;
            border: 1px solid #ccc;
            border-radius: 4px;
        }

        button {
            margin-top: 15px;
            width: 100%;
            padding: 10px;
            background-color: #4CAF50;
            color: #fff;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            font-size: 16px;
        }

        button:hover {
            background-color: #45a049;
        }

        /* Retrieve Section Styling */
        .retrieve-section {
            background-color: #fff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0px 4px 10px rgba(0, 0, 0, 0.1);
            text-align: center;
        }

        .retrieve-section h2 {
            color: #4CAF50;
            margin-bottom: 15px;
        }

        .retrieve-section input[type="text"] {
            width: 80%;
            padding: 10px;
            margin-right: 10px;
            border: 1px solid #ccc;
            border-radius: 4px;
        }

        .results {
            margin-top: 20px;
            text-align: left;
        }

        /* Button Styling */
        .btn-primary {
            background: linear-gradient(135deg, #4CAF50, #66bb6a);
            color: white;
            text-decoration: none;
            padding: 12px 24px;
            border-radius: 8px;
            font-size: 16px;
            font-weight: bold;
            text-align: center;
            display: inline-block;
            transition: all 0.3s ease-in-out;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1), 0 1px 3px rgba(0, 0, 0, 0.08);
        }

        .btn-primary:hover {
            background: linear-gradient(135deg, #66bb6a, #4CAF50);
            transform: translateY(-4px);
            box-shadow: 0 6px 12px rgba(0, 0, 0, 0.15), 0 2px 4px rgba(0, 0, 0, 0.1);
        }

        .btn-primary:active {
            transform: translateY(2px);
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
        }

        .btn-primary:focus {
            outline: none;
            border: 2px solid #66bb6a;
        }

        /* Positioning the Back button at top left */
        .btn-back {
            position: absolute;
            top: 20px;
            left: 20px;
            background: linear-gradient(135deg, #4CAF50, #66bb6a);
            color: white;
            padding: 12px 18px;
            border-radius: 8px;
            font-size: 14px;
            font-weight: bold;
            text-decoration: none;
            transition: all 0.3s ease-in-out;
        }

        .btn-back:hover {
            background: linear-gradient(135deg, #66bb6a, #4CAF50);
            transform: translateY(-4px);
        }

        .btn-back:active {
            transform: translateY(2px);
        }
    </style>
</head>

<body>
    <a href="dashboard.php" class="btn-back">Back</a>
    <div class="wrapper">

        <!-- Upload Section -->
        <div class="upload-container">
            <div class="upload-section" id="upload-id">
                <h2>Upload ID</h2>
                <form action="upload.php" method="post" enctype="multipart/form-data">
                    <label for="idFile">Select ID file:</label>
                    <input type="file" id="idFile" name="idFile" required>
                    <label for="idName">ID Saving:</label>
                    <input type="text" id="idName" name="idName" placeholder="Save Name of ID" required>
                    <button type="submit" name="upload_id">Upload ID</button>
                </form>
                <?php if ($idUploadMessage): ?>
                    <p><?php echo $idUploadMessage; ?></p>
                <?php endif; ?>
            </div>

            <div class="upload-section" id="upload-doc">
                <h2>Upload Document</h2>
                <form action="upload.php" method="post" enctype="multipart/form-data">
                    <label for="docFile">Select Document file:</label>
                    <input type="file" id="docFile" name="docFile" required>
                    <label for="docName">Document Saving:</label>
                    <input type="text" id="docName" name="docName" placeholder="Save Name of Document" required>
                    <button type="submit" name="upload_doc">Upload Document</button>
                </form>
                <?php if ($docUploadMessage): ?>
                    <p><?php echo $docUploadMessage; ?></p>
                <?php endif; ?>
            </div>
        </div>

        <!-- Retrieve Section -->
        <div class="retrieve-section">
            <h2>Retrieve Files</h2>
            <form action="retrieve.php" method="get">
                <input type="text" id="searchInput" name="search" placeholder="Search by name">
                <button type="submit">Retrieve</button>
            </form>
        </div>

    </div>
</body>

</html>
