<?php
session_start();
include "db_conn.php";

if (isset($_POST['admin_uname']) && isset($_POST['admin_password']) && isset($_POST['access_code'])) {
    function validate($data)
    {
        $data = trim($data);
        $data = stripslashes($data);
        $data = htmlspecialchars($data);
        return $data;
    }

    $admin_uname = validate($_POST['admin_uname']);
    $pass = validate($_POST['admin_password']);
    $access_code = validate($_POST['access_code']);

    if (empty($admin_uname)) {
        header("Location: admin_login.php?error=Admin Username is required");
        exit();
    } else if (empty($pass)) {
        header("Location: admin_login.php?error=Admin Password is required");
        exit();
    } else if (empty($access_code)) {
        header("Location: admin_login.php?error=Access Code is required");
        exit();
    }

    $pass = md5($pass);
    $sql = "SELECT * FROM admin_users WHERE admin_username='$admin_uname' 
            AND admin_password='$pass' AND access_code='$access_code'";
    $result = mysqli_query($conn, $sql);

    if (mysqli_num_rows($result) === 1) {
        $row = mysqli_fetch_assoc($result);
        $_SESSION['admin_id'] = $row['id'];
        $_SESSION['admin_name'] = $row['admin_name'];
        $_SESSION['admin_username'] = $row['admin_username'];
        header("Location: admin_dashboard.php");
        exit();
    } else {
        header("Location: admin_login.php?error=Incorrect Username, Password or Access Code");
        exit();
    }
}
