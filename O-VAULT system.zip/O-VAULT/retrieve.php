<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "test_db";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$searchMessage = "";
$searchResults = [];

if ($_SERVER['REQUEST_METHOD'] == 'GET' && isset($_GET['search'])) {
    $search = $_GET['search'];
    
    // Retrieve IDs
    $sql = "SELECT * FROM ids WHERE id_name LIKE ?";
    $stmt = $conn->prepare($sql);
    $likeSearch = "%" . $search . "%";
    $stmt->bind_param("s", $likeSearch);
    $stmt->execute();
    $idResult = $stmt->get_result();
    $searchResults['ids'] = $idResult->fetch_all(MYSQLI_ASSOC);

    // Retrieve Documents
    $sql = "SELECT * FROM documents WHERE document_name LIKE ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $likeSearch);
    $stmt->execute();
    $docResult = $stmt->get_result();
    $searchResults['documents'] = $docResult->fetch_all(MYSQLI_ASSOC);
    
    $stmt->close();
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Retrieve Files</title>
    <style>
        /* Global Styling */
        body {
            font-family: Arial, sans-serif;
            background-color: #f5f5f5;
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
            margin: 0;
        }

        .wrapper {
            width: 80%;
            max-width: 1000px;
            margin: 20px;
            display: flex;
            flex-direction: column;
            gap: 30px;
        }

        /* Upload Section Styling */
        .upload-container {
            display: flex;
            justify-content: space-between;
            gap: 20px;
        }

        .upload-section {
            flex: 1;
            background-color: #ffffff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0px 4px 10px rgba(0, 0, 0, 0.1);
        }

        .upload-section h2 {
            color: #4CAF50;
            margin-bottom: 15px;
            text-align: center;
        }

        label {
            display: block;
            margin-top: 10px;
            font-weight: bold;
        }

        input[type="file"],
        input[type="text"] {
            width: 100%;
            padding: 8px;
            margin-top: 5px;
            border: 1px solid #ccc;
            border-radius: 4px;
        }

        button {
            margin-top: 15px;
            width: 100%;
            padding: 10px;
            background-color: #4CAF50;
            color: #fff;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            font-size: 16px;
        }

        button:hover {
            background-color: #45a049;
        }

        /* Retrieve Section Styling */
        .retrieve-section {
            background-color: #fff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0px 4px 10px rgba(0, 0, 0, 0.1);
            text-align: center;
        }

        .retrieve-section h2 {
            color: #4CAF50;
            margin-bottom: 15px;
        }

        .retrieve-section input[type="text"] {
            width: 80%;
            padding: 10px;
            margin-right: 10px;
            border: 1px solid #ccc;
            border-radius: 4px;
        }

        .results {
            margin-top: 20px;
            text-align: left;
        }

        /* Button Styling */
        .btn-primary {
            background: linear-gradient(135deg, #4CAF50, #66bb6a);
            color: white;
            text-decoration: none;
            padding: 12px 24px;
            border-radius: 8px;
            font-size: 16px;
            font-weight: bold;
            text-align: center;
            display: inline-block;
            transition: all 0.3s ease-in-out;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1), 0 1px 3px rgba(0, 0, 0, 0.08);
        }

        .btn-primary:hover {
            background: linear-gradient(135deg, #66bb6a, #4CAF50);
            transform: translateY(-4px);
            box-shadow: 0 6px 12px rgba(0, 0, 0, 0.15), 0 2px 4px rgba(0, 0, 0, 0.1);
        }

        .btn-primary:active {
            transform: translateY(2px);
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
        }

        .btn-primary:focus {
            outline: none;
            border: 2px solid #66bb6a;
        }

        /* Positioning the Back button at top left */
        .btn-back {
            position: absolute;
            top: 20px;
            left: 20px;
            background: linear-gradient(135deg, #4CAF50, #66bb6a);
            color: white;
            padding: 12px 18px;
            border-radius: 8px;
            font-size: 14px;
            font-weight: bold;
            text-decoration: none;
            transition: all 0.3s ease-in-out;
        }

        .btn-back:hover {
            background: linear-gradient(135deg, #66bb6a, #4CAF50);
            transform: translateY(-4px);
        }

        .btn-back:active {
            transform: translateY(2px);
        }
    </style>
</head>

<body>
    <a href="upload.php" class="btn-back">Back</a>
    <div class="wrapper">

        <!-- Retrieve Section -->
        <div class="retrieve-section">
            <h2>Retrieve Files</h2>
            <form action="retrieve.php" method="get">
                <input type="text" id="searchInput" name="search" placeholder="Search by name" value="<?php echo isset($_GET['search']) ? htmlspecialchars($_GET['search']) : ''; ?>">
                <button type="submit">Search</button>
            </form>

            <div class="results">
                <h3>IDs</h3>
                <?php if (!empty($searchResults['ids'])): ?>
                    <?php foreach ($searchResults['ids'] as $id): ?>
                        <p><a href="download.php?table=ids&id=<?php echo $id['id']; ?>">Download <?php echo $id['id_name']; ?></a></p>
                    <?php endforeach; ?>
                <?php else: ?>
                    <p>No IDs found</p>
                <?php endif; ?>

                <h3>Documents</h3>
                <?php if (!empty($searchResults['documents'])): ?>
                    <?php foreach ($searchResults['documents'] as $doc): ?>
                        <p><a href="download.php?table=documents&id=<?php echo $doc['id']; ?>">Download <?php echo $doc['document_name']; ?></a></p>
                    <?php endforeach; ?>
                <?php else: ?>
                    <p>No documents found</p>
                <?php endif; ?>
            </div>
        </div>

    </div>
</body>

</html>
