<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ADMIN LOGIN</title>
    <link rel="stylesheet" href="admin_sign_up and login.css">
</head>
<style>
    .back-btn {
        position: absolute;
        top: 40px;
        right: 95px;
        padding: 10px 15px;
        width: auto;
        background-color: #007bff;
        color: whitesmoke;
        border: none;
        border-radius: 5px;
        font-size: 14px;
        font-weight: bold;
        cursor: pointer;
        transition: background-color 0.25s;
        box-sizing: border-box;
    }

    .back-btn:hover {
        background-color: red;
        color: black;
    }
</style>

<body>
    <div class="background">
        <form action="admin_login_check.php" method="post" class="form-container">
            <h2>ADMIN LOGIN</h2>
            <?php if (isset($_GET['error'])) { ?>
                <p class="error"><?php echo $_GET['error']; ?></p>
            <?php } ?>

            <label for="admin_uname">Admin Username</label>
            <input type="text" id="admin_uname" name="admin_uname" placeholder="Admin Username" required><br>

            <label for="admin_password">Admin Password</label>
            <input type="password" id="admin_password" name="admin_password" placeholder="Admin Password" required><br>

            <label for="access_code">Access Code</label>
            <input type="password" id="access_code" name="access_code" placeholder="Admin Access Code" required><br>

            <button type="submit">Login as Admin</button>
            <div class="signup-link">
                <a href="admin_sign_up.php">Create an account</a>
            </div>
            <button onclick="window.location.href='index.php'" class="back-btn">Back to User Login</button>
        </form>
    </div>
</body>

</html>