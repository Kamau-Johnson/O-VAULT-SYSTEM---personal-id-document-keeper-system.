<?php
session_start(); // Start the session

// Check if the user is not logged in, redirect to login page
if (!isset($_SESSION['user_name'])) {
    header("Location: index.php");
    exit();
}

// Establish database connection
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "test_db";
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Fetch statistics
$documentCount = $conn->query("SELECT COUNT(*) AS count FROM documents")->fetch_assoc()['count'];
$idCount = $conn->query("SELECT COUNT(*) AS count FROM ids")->fetch_assoc()['count'];
$recentUploadsCount = $conn->query("SELECT COUNT(*) AS count FROM (SELECT id FROM documents UNION ALL SELECT id FROM ids) AS t")->fetch_assoc()['count'];

// Fetch username
$user_name = $_SESSION['user_name'];
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard</title>
    <style>
        /* Global styles */
        * {
            box-sizing: border-box;
            margin: 0;
            padding: 0;
        }

        body {
            font-family: Arial, sans-serif;
            background-color: #f8f9fa;
        }

        h1 {
            font-size: 23px;
            text-align: center;
        }

        h2 {
            font-size: 30px;
        }

        /* Header styles */
        .header {
            background-color: #007bff;
            color: white;
            padding: 38px;
            text-align: center;
            position: relative;
        }

        /* Back Button */
        .back-button {
            position: absolute;
            right: 30px;
            top: 140%;
            transform: translateY(-50%);
            background-color: #6c757d;
            color: white;
            padding: 10px 20px;
            text-decoration: none;
            border-radius: 5px;
            font-size: 16px;
            transition: background-color 0.3s;
        }

        .back-button:hover {
            background-color: #5a6268;
        }

        /* Dashboard container */
        .dashboard-container {
            display: flex;
            margin-top: 20px;
        }

        /* Sidebar styles */
        .sidebar {
            width: 250px;
            background-color: #343a40;
            color: white;
            padding: 15px;
            position: relative;
        }

        .sidebar h3 {
            margin-bottom: 20px;
        }

        .sidebar ul {
            list-style-type: none;
        }

        .sidebar li {
            margin: 15px 0;
        }

        .sidebar a {
            color: white;
            text-decoration: none;
            transition: color 0.3s;
        }

        .sidebar a:hover {
            color: #007bff;
        }

        .logout-button {
            background-color: #d9534f;
            color: white;
            padding: 10px;
            border: none;
            text-align: center;
            border-radius: 5px;
            cursor: pointer;
            position: absolute;
            bottom: 20px;
            left: 15px;
            width: 85%;
        }

        .logout-button:hover {
            background-color: #c9302c;
        }

        /* Profile section styles */
        .profile-section {
            margin-bottom: 15px;
        }

        .profile-container {
            display: flex;
            flex-direction: column;
            align-items: flex-start;
            margin-left: 20px;
        }

        .profile-pic {
            width: 95px;
            height: 95px;
            border-radius: 50%;
            overflow: hidden;
            border: 2px solid #007bff;
            margin-bottom: 10px;
            cursor: pointer;
        }

        .profile-pic img {
            width: 100%;
            height: 100%;
            object-fit: cover;
        }

        .username {
            font-size: 20px;
            color: #333;
            margin-bottom: 10px;
        }

        .upload-profile-pic {
            display: flex;
            flex-direction: column;
            align-items: flex-start;
        }

        .upload-profile-pic form {
            display: flex;
            flex-direction: column;
            align-items: flex-start;
        }

        .upload-profile-pic input[type="file"] {
            display: none;
        }

        .upload-profile-pic label.choose-image-button {
            background-color: #007bff;
            color: white;
            padding: 7px;
            border-radius: 5px;
            text-align: center;
            cursor: pointer;
            margin-top: 10px;
        }

        .upload-profile-pic button {
            background-color: #28a745;
            color: white;
            padding: 10px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            margin-top: 10px;
        }

        .upload-profile-pic button:hover {
            background-color: #218838;
        }

        /* Main content styles */
        .main-content {
            flex: 1;
            padding: 20px;
        }

        /* Overview section */
        .overview-section {
            background-color: #ffffff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
            margin-top: 10px;
        }

        .quick-stats {
            display: flex;
            justify-content: space-between;
        }

        .stat {
            text-align: center;
            flex: 1;
            margin: 0 10px;
        }

        .stat h4 {
            margin-bottom: 10px;
            color: #007bff;
        }

        .stat p {
            font-size: 24px;
            font-weight: bold;
            color: #333;
        }

        /* Profile picture choose text */
        .choose-img {
            margin-bottom: 10px;
        }

        /* Maginary box (aligned to the right) */
        .maginary-box {
            width: 5cm;
            height: 5cm;
            border: 2px dashed #007bff; /* Dashed blue border */
            background-color: #f1f1f1; /* Light gray background */
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: flex-start;
            text-align: left;
            padding: 10px;
            font-size: 14px; /* Set a readable but smaller font size */
            color: black;
            box-sizing: border-box; /* Ensure padding doesn't affect total box size */
            word-wrap: break-word; /* Allow long words to break inside the box */
            position: absolute; /* Position it absolutely */
            right: 120px; /* Align to the right with some margin */
            top: 210px; /* Adjust its vertical position */
            overflow: hidden; /* Hide overflowing content */
            white-space: normal; /* Ensure content wraps normally */
        }

        .maginary-box h4 {
            font-size: 16px; /* Adjust heading size to fit */
            margin-bottom: 10px;
            font-weight: bold;
        }

        .maginary-box p {
            font-size: 12px; /* Reduce text size to fit well inside the box */
            line-height: 1.5; /* Adjust line height for better readability */
            margin: 0; /* Remove margins to avoid overflow */
        }
    </style>
</head>
<body>
    <h1>Your Documents, Safeguarded for Tomorrow.</h1>
    <header class="header">
        <h2>O-VAULT System</h2>
        <!-- Back Button -->
        <a href="home.php" class="back-button">Back</a>
    </header>

    <div class="dashboard-container">
        <aside class="sidebar">
            <h3>Navigation Bar</h3>
            <ul>
                <li><a href="view.php">View</a></li>
                <li><a href="upload.php">Upload</a></li>
                <li><a href="doc_manage.php">Doc Manage</a></li>
                <li><a href="id_manage.php">ID Manage</a></li>
            </ul>
            <a href="logout.php" class="logout-button">Log Out</a>
        </aside>

        <div class="main-content">
            <div class="profile-section">
                <h2>Profile</h2>
                <div class="profile-container">
                    <div class="profile-pic">
                        <img id="output" src="get_profile_pic.php?user_id=<?php echo $_SESSION['id']; ?>" alt="" />
                        <div class="choose-img" id="choose-img"></div>
                    </div>
                    <div class="username">
                        <p><?php echo htmlspecialchars($user_name); ?></p>
                    </div>
                    <div class="upload-profile-pic">
                        <form action="upload_profile_pic.php" method="POST" enctype="multipart/form-data">
                            <label for="profile-pic-file" class="choose-image-button">Choose Image</label>
                            <input type="file" id="profile-pic-file" name="profile-pic-file" accept=".jpg, .jpeg, .png" style="display: none;" required>
                            <button type="submit" id="upload-button" style="display: none;">Upload</button>
                            <p class="error" id="profile-pic-error"></p>
                        </form>
                    </div>
                </div>
            </div>
            <div class="overview-section">
                <h2>Overview</h2>
                <div class="quick-stats">
                    <div class="stat">
                        <h4>Documents Stored</h4>
                        <p id="doc-count"><?php echo $documentCount; ?></p>
                    </div>
                    <div class="stat">
                        <h4>IDs Stored</h4>
                        <p id="id-count"><?php echo $idCount; ?></p>
                    </div>
                    <div class="stat">
                        <h4>Recent Uploads</h4>
                        <p id="recent-uploads"><?php echo $recentUploadsCount; ?></p>
                    </div>
                    <!-- Display a "maginary box" with a message -->
                <div class="maginary-box">
                    <h4>Note</h4>
                    <p>Feel free to explore the dashboard features, view, and manage your documents and IDs. Upload securely anytime!</p>
                </div>
                </div>
            </div>
        </div>
    </div>

    <script>
        document.getElementById("profile-pic-file").addEventListener("change", function(event) {
            var file = event.target.files[0];
            if (file && (file.type == "image/jpeg" || file.type == "image/png")) {
                document.getElementById("upload-button").style.display = "inline";
            } else {
                document.getElementById("profile-pic-error").textContent = "Please upload a valid image file (JPEG/PNG).";
                document.getElementById("upload-button").style.display = "none";
            }
        });
    </script>

</body>
</html>
