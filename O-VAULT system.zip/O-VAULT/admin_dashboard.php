<?php
session_start();
include "db_conn.php";

if (!isset($_SESSION['admin_id'])) {
    header("Location: admin_login.php");
    exit();
}

// Handle logout
if (isset($_POST['logout'])) {
    session_unset();
    session_destroy();
    header("Location: admin_login.php");
    exit();
}

// Fetch statistics
$userCount = $conn->query("SELECT COUNT(*) AS count FROM users")->fetch_assoc()['count'];
$documentCount = $conn->query("SELECT COUNT(*) AS count FROM documents")->fetch_assoc()['count'];
$idCount = $conn->query("SELECT COUNT(*) AS count FROM ids")->fetch_assoc()['count'];

// Fetch admin name
$admin_name = $_SESSION['admin_name'];
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            display: flex;
            font-family: Arial, sans-serif;
            background: #f4f6f9;
        }

        .sidebar {
            width: 250px;
            background: #343a40;
            color: #fff;
            padding: 20px;
            height: 100vh;
            position: fixed;
        }

        .profile {
            text-align: center;
            padding: 20px 0;
            border-bottom: 1px solid #4f5962;
        }

        .profile-pic {
            width: 100px;
            height: 100px;
            background: #4f5962;
            border-radius: 50%;
            margin: 0 auto 15px;
            display: flex;
            align-items: center;
            justify-content: center;
        }

        .admin-icon {
            font-size: 40px;
            color: #fff;
        }

        nav ul {
            list-style: none;
            margin-top: 20px;
        }

        nav ul li {
            margin-bottom: 10px;
        }

        nav ul li a {
            color: #fff;
            text-decoration: none;
            display: block;
            padding: 10px;
            border-radius: 5px;
            transition: background 0.3s;
        }

        nav ul li a:hover,
        nav ul li a.active {
            background: #4f5962;
        }

        nav ul li a i {
            margin-right: 10px;
        }

        .main-content {
            margin-left: 250px;
            padding: 20px;
            width: 100%;
        }

        header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 30px;
            background: #fff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
        }

        .stats-container {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 20px;
            margin-bottom: 30px;
        }

        .stat-card {
            background: #fff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
            text-align: center;
        }

        .stat-card i {
            font-size: 30px;
            color: #007bff;
            margin-bottom: 10px;
        }

        .recent-activities {
            background: #fff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
            margin-bottom: 30px;
        }

        .activity-item {
            padding: 10px 0;
            border-bottom: 1px solid #eee;
        }

        .activity-item .time {
            color: #666;
            font-size: 0.9em;
            margin-right: 10px;
        }

        .logout-form {
            margin-top: auto;
        }

        .logout-btn {
            width: 100%;
            padding: 10px;
            background: #dc3545;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            transition: background 0.3s;
        }

        .logout-btn:hover {
            background: #c82333;
        }

        @media (max-width: 768px) {
            .sidebar {
                width: 100%;
                position: relative;
                height: auto;
            }

            .main-content {
                margin-left: 0;
                padding: 10px;
            }

            .stats-container {
                grid-template-columns: 1fr;
            }
        }
    </style>
</head>

<body>
    <div class="sidebar">
        <div class="profile">
            <div class="profile-pic">
                <i class="fas fa-user-shield admin-icon"></i>
            </div>
            <p>Welcome,<br><?php echo htmlspecialchars($admin_name); ?></p>
        </div>
        <nav>
            <ul>
                <li><a href="#" class="active"><i class="fas fa-home"></i> Dashboard</a></li>
                <li><a href="user_admin_dashboard.php"><i class="fas fa-users"></i> Users</a></li>
                <li><a href="admin doc_manage.php"><i class="fas fa-file"></i> Documents</a></li>
                <li><a href="admin id_manage.php"><i class="fas fa-id-card"></i> IDs</a></li>
            </ul>
        </nav>
        <form method="POST" class="logout-form">
            <button type="submit" name="logout" class="logout-btn">
                <i class="fas fa-sign-out-alt"></i> Logout
            </button>
        </form>
    </div>

    <div class="main-content">
        <header>
            <h1>Admin Control Panel</h1>
        </header>

        <div class="stats-container">
            <div class="stat-card">
                <i class="fas fa-users"></i>
                <h3>Total Users</h3>
                <p><?php echo $userCount; ?></p>
            </div>
            <div class="stat-card">
                <i class="fas fa-file"></i>
                <h3>Documents</h3>
                <p><?php echo $documentCount; ?></p>
            </div>
            <div class="stat-card">
                <i class="fas fa-id-card"></i>
                <h3>IDs</h3>
                <p><?php echo $idCount; ?></p>
            </div>
        </div>
        </div>
    </div>
</body>

</html>
