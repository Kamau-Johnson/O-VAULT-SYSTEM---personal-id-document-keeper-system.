<?php
session_start();
include "db_conn.php";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = $_POST['name'];
    $email = $_POST['email'];
    $subject = $_POST['subject'];
    $message = $_POST['message'];
    
    // Insert the contact message into the database
    $sql = "INSERT INTO contact_messages (name, email, subject, message) VALUES (?, ?, ?, ?)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ssss", $name, $email, $subject, $message);
    
    if ($stmt->execute()) {
        $success_msg = "Message sent successfully!";
    } else {
        $error_msg = "Failed to send message, please try again later.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Contact Us | O-VAULT</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        /* Basic Reset */
        * {
            box-sizing: border-box;
            margin: 0;
            padding: 0;
        }

        /* Body Styling */
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-image: url('Contact.webp');
            background-size: cover;
            background-position: center;
            background-attachment: fixed;
            color: #fff;
            margin: 0;
            padding: 0;
        }

        .overlay {
            background: rgba(0, 0, 0, 0.7);
            min-height: 100vh;
            padding: 50px 20px;
        }

        .container {
            max-width: 900px;
            margin: 0 auto;
        }

        .contact-wrapper {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 30px;
            margin-top: 50px;
            width: 100%;
            margin-left: auto;
            margin-right: auto;
        }

        .contact-info {
            padding: 30px;
            background: rgba(255, 255, 255, 0.1);
            border-radius: 15px;
            backdrop-filter: blur(10px);
        }

        .contact-form {
            padding: 45px;
            background: rgba(255, 255, 255, 0.1);
            border-radius: 15px;
            backdrop-filter: blur(10px);
        }

        h1 {
            font-size: 2.5em;
            margin-bottom: 20px;
            text-align: center;
        }

        .info-item {
            margin-bottom: 30px;
        }

        .info-item i {
            font-size: 24px;
            margin-right: 15px;
            color: #2196F3;
        }

        .form-group {
            margin-bottom: 20px;
        }

        input, textarea {
            width: 100%;
            padding: 12px;
            border: none;
            background: rgba(255, 255, 255, 0.1);
            border-radius: 5px;
            color: #fff;
            margin-top: 5px;
        }

        textarea {
            height: 150px;
            resize: vertical;
        }

        button {
            background: #2196F3;
            color: #fff;
            padding: 12px 30px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 16px;
            transition: background 0.3s;
        }

        button:hover {
            background: #1976D2;
        }

        .success-message {
            background: rgba(76, 175, 80, 0.3);
            padding: 15px;
            border-radius: 5px;
            margin-bottom: 20px;
        }

        .error-message {
            background: rgba(255, 0, 0, 0.3);
            padding: 15px;
            border-radius: 5px;
            margin-bottom: 20px;
        }

        @media (max-width: 768px) {
            .contact-wrapper {
                grid-template-columns: 1fr;
            }
        }

        /* Back Button Positioned on Left */
    .back-btn {
        position: absolute;
        top: 40px; /* Adjust the vertical position */
        left: 20px; /* Align the button to the left */
        padding: 10px 15px;
        width: auto;
        background-color: black;
        color: yellowgreen;
        border: none;
        border-radius: 5px;
        font-size: 14px;
        font-weight: bold;
        cursor: pointer; /* Change cursor to indicate the button is clickable */
        text-decoration: none; /* Remove underline */
        transition: background-color 0.25s;
        box-sizing: border-box;
    }

    .back-btn:hover {
        background-color: cyan;
        color: black;
    }
    </style>
</head>
<body>
    <!-- Back Button Positioned on Left -->
    <a href="home.php" class="back-btn">
        Back
    </a>

    <div class="overlay">
        <div class="container">
            <h1>Contact Us</h1>
            <p>Send us your feedback or inquiries, and we'll get back to you as soon as possible.</p>
            
            <div class="contact-wrapper">
                <div class="contact-info">
                    <div class="info-item">
                        <i class="fas fa-map-marker-alt"></i>
                        <h3>Our Location</h3>
                        <p>Tumaini Drive, 882356</p>
                    </div>
                    
                    <div class="info-item">
                        <i class="fas fa-envelope"></i>
                        <h3>Email Us</h3>
                        <p>o-vault@gmail.com</p>
                    </div>
                    
                    <div class="info-item">
                        <i class="fas fa-phone"></i>
                        <h3>Call Us</h3>
                        <p>+254 768280952</p>
                    </div>
                </div>
                
                <div class="contact-form">
                    <?php if (isset($success_msg)): ?>
                        <div class="success-message">
                            <?php echo $success_msg; ?>
                        </div>
                    <?php elseif (isset($error_msg)): ?>
                        <div class="error-message">
                            <?php echo $error_msg; ?>
                        </div>
                    <?php endif; ?>
                    
                    <form method="POST" action="">
                        <div class="form-group">
                            <label for="name">Name</label>
                            <input type="text" id="name" name="name" required>
                        </div>
                        
                        <div class="form-group">
                            <label for="email">Email</label>
                            <input type="email" id="email" name="email" required>
                        </div>
                        
                        <div class="form-group">
                            <label for="subject">Subject</label>
                            <input type="text" id="subject" name="subject" required>
                        </div>
                        
                        <div class="form-group">
                            <label for="message">Message</label>
                            <textarea id="message" name="message" required></textarea>
                        </div>
                        
                        <button type="submit">Send Message</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</body>
</html>
