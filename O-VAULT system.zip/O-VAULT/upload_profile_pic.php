<?php
session_start();

// Database configuration
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "test_db";

// Create a new database connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Ensure the user is logged in
if (!isset($_SESSION['user_name']) || !isset($_SESSION['id'])) {
    header("Location: index.php"); // Redirect to login if not logged in
    exit();
}

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_FILES["profile-pic-file"])) {
    $file = $_FILES["profile-pic-file"];
    $filename = $file["name"];
    $filetype = $file["type"];
    $filesize = $file["size"];
    $userId = $_SESSION['id']; // Use session ID for the user

    // Validate file type and size
    if (!in_array($filetype, ["image/jpeg", "image/png"])) {
        echo "Invalid file type. Only JPG and PNG files are allowed.";
        exit();
    }

    if ($filesize > 2 * 1024 * 1024) { // 2MB limit
        echo "File is too large. Maximum size is 2MB.";
        exit();
    }

    // Read file content as binary data
    $filedata = file_get_contents($file["tmp_name"]);

    // Start a transaction to handle the profile picture update
    $conn->begin_transaction();

    try {
        // Remove old profile picture if it exists
        $deleteSql = "DELETE FROM profile_pics WHERE user_id = ?";
        $stmt = $conn->prepare($deleteSql);
        $stmt->bind_param("i", $userId);
        $stmt->execute();
        $stmt->close();

        // Insert the new profile picture
        $insertSql = "INSERT INTO profile_pics (user_id, filename, content_type, data) VALUES (?, ?, ?, ?)";
        $stmt = $conn->prepare($insertSql);
        $stmt->bind_param("isss", $userId, $filename, $filetype, $filedata);

        if (!$stmt->execute()) {
            throw new Exception("Error: " . $stmt->error);
        }

        // Commit the transaction
        $conn->commit();
        echo "Profile picture uploaded successfully.";
    } catch (Exception $e) {
        // Roll back the transaction on error
        $conn->rollback();
        error_log($e->getMessage());
        echo "Error: " . $e->getMessage();
    }

    // Close the statement
    $stmt->close();

    // Redirect back to the dashboard after the upload
    header("Location: dashboard.php");
    exit();
}

// Close the database connection
$conn->close();
