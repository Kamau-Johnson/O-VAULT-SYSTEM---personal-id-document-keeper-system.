<?php
session_start();
if (!isset($_SESSION['user_name'])) {
    header("Location: index.php");
    exit();
}

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "test_db";
$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$ids = $conn->query("SELECT * FROM ids");
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage IDs</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
        }
        .header {
            background-color: #007bff;
            color: white;
            padding: 15px;
            text-align: center;
        }
        .btn-primary {
            background-color: #4CAF50;
            color: white;
            text-decoration: none;
            padding: 10px 15px;
            margin-top: 10px;
            border-radius: 5px;
        }
        .btn-primary:hover {
            background-color: #45a049;
        }
        .delete-btn {
            position: absolute;
            top: 135px;
            right: 40px;
            background-color: black;
            color: yellowgreen;
            border: none;
            padding: 10px 20px;
            font-size: 16px;
            border-radius: 5px;
            cursor: pointer;
            transition: background-color 0.3s ease, box-shadow 0.3s ease;
        }
        .delete-btn:hover {
            background-color: white;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
        }
        .container {
            max-width: 1200px;
            margin: 20px auto;
            padding: 0 15px;
        }
        h3 {
            font-size: 24px;
            color: #333;
            margin-top: 30px;
            border-bottom: 2px solid #ddd;
            padding-bottom: 10px;
        }
        .grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(280px, 1fr));
            gap: 20px;
            margin-top: 20px;
        }
        .card {
            background-color: #fff;
            padding: 15px;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            transition: box-shadow 0.3s ease;
        }
        .card:hover {
            box-shadow: 0 8px 16px rgba(0, 0, 0, 0.2);
        }
        .card h4 {
            font-size: 18px;
            color: #333;
            margin-bottom: 10px;
        }
        .card p {
            font-size: 14px;
            color: #666;
            margin: 5px 0;
        }
        @media (max-width: 768px) {
            .grid {
                grid-template-columns: repeat(auto-fill, minmax(250px, 1fr));
            }
            .card {
                padding: 10px;
            }
            .btn-primary {
                font-size: 14px;
                padding: 8px 12px;
            }
            .delete-btn {
                font-size: 14px;
                padding: 8px 16px;
            }
        }
    </style>
</head>
<body>

<header class="header">
    <h2>Manage IDs</h2>
    <a href="dashboard.php" class="btn-primary">Back</a>
</header>

<div class="container">
    <h3>IDs</h3>
    <form id="delete-form">
        <div class="grid">
            <?php if ($ids->num_rows > 0): ?>
                <?php while ($id = $ids->fetch_assoc()) { ?>
                    <div class="card">
                        <input type="checkbox" class="id-checkbox" data-id="<?php echo $id['id']; ?>" />
                        <h4><?php echo htmlspecialchars($id['id_name'] ?? 'No Name'); ?></h4>
                        <p><strong>Uploaded on:</strong> <?php echo isset($id['upload_date']) ? date('M d, Y', strtotime($id['upload_date'])) : 'N/A'; ?></p>
                    </div>
                <?php } ?>
            <?php else: ?>
                <p>No IDs found.</p>
            <?php endif; ?>
        </div>
        <button type="button" class="delete-btn" id="delete-button">Delete</button>
    </form>
</div>

<script>
document.getElementById('delete-button').addEventListener('click', function() {
    const selectedIds = [];
    document.querySelectorAll('.id-checkbox:checked').forEach(function(checkbox) {
        selectedIds.push(checkbox.getAttribute('data-id'));
    });

    if (selectedIds.length === 0) {
        alert('Please select at least one ID to delete.');
        return;
    }

    const xhr = new XMLHttpRequest();
    xhr.open('POST', 'delete_ids.php', true);
    xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
    xhr.onload = function() {
        if (xhr.status === 200) {
            alert('IDs deleted successfully.');
            location.reload();
        } else {
            alert('Error deleting IDs: ' + xhr.responseText);
        }
    };
    xhr.send('ids=' + JSON.stringify(selectedIds));
});
</script>

</body>
</html>

<?php
$conn->close();
?>
