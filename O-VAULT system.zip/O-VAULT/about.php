<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>About Us - ID & Document Keeper System</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            color: #333;
            line-height: 1.6;
            padding: 20px;
        }

        .about-container {
            max-width: 1200px;
            margin: 0 auto;
            padding: 20px;
            background-color: white;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            border-radius: 8px;
        }

        .about-container h1,
        h2 {
            color: #007bff;
            text-align: center;
            margin-bottom: 20px;
        }

        .about-container p {
            font-size: 1.1em;
            margin-bottom: 20px;
        }

        .how-it-works,
        .what-we-do,
        .who-can-benefit {
            margin-bottom: 40px;
        }

        .how-it-works ol {
            list-style-type: decimal;
            margin-left: 20px;
        }

        .how-it-works li {
            margin-bottom: 10px;
        }

        .who-can-benefit ul {
            list-style-type: disc;
            margin-left: 20px;
        }

        .who-can-benefit li {
            margin-bottom: 10px;
        }

        .about-container section {
            padding: 20px;
            border-bottom: 1px solid #e0e0e0;
        }

        .about-container section:last-of-type {
            border-bottom: none;
        }

        /* Call to Action Section */
        .cta {
            background-color: #f33c3c;
            padding: 15px;
            text-align: center;
            color: #fff;
        }

        .cta h2 {
            font-size: 2.5rem;
            margin-bottom: 15px;
        }

        .cta-btn {
            background-color: #fff;
            color: #f33c3c;
            padding: 8px 25px;
            text-transform: uppercase;
            font-weight: bold;
            border-radius: 50px;
            text-decoration: none;
        }

        .cta-btn:hover {
            background-color: greenyellow;
            transition: background-color 0.3s ease;
        }

        /* Back Button Positioned on Left */
    .back-btn {
        position: absolute;
        top: 40px; /* Adjust the vertical position */
        left: 50px; /* Align the button to the left */
        padding: 8px 10px;
        width: auto;
        background-color: black;
        color: yellowgreen;
        border: none;
        border-radius: 5px;
        font-size: 14px;
        font-weight: bold;
        cursor: pointer; /* Change cursor to indicate the button is clickable */
        text-decoration: none; /* Remove underline */
        transition: background-color 0.25s;
        box-sizing: border-box;
    }

    .back-btn:hover {
        background-color: cyan;
        color: black;
    }
    </style>
</head>

<body>
    <!-- Back Button Positioned on Left -->
    <a href="home.php" class="back-btn">
        Back
    </a> 

    <div class="about-container">
        <section class="about-intro">
            <h1>About</h1>
            <p>Welcome to 0-VAULT, your secure solution for managing personal IDs and important documents in one place.</p>
        </section>
        <section class="how-it-works">
            <h2>How It Works</h2>
            <ol>
                <li>Register and create an account.</li>
                <li>Upload your personal IDs and documents in the Dashboard page.</li>
                <li>In the Upload feature, you can choose if either ID or Documents is to be stored.</li>
                <li>Save the desired documents or retrieve them in your Liking.</li>
                <li>Enjoy peace of mind knowing your data is safe with encrypted storage.</li>
            </ol>
        </section>
        <section class="what-we-do">
            <h2>Functions Of The System</h2>
            <p>
                O-VAULT is a comprehensive system designed to securely manage your personal IDs and important documents. With easy
                upload options for both IDs and documents, users can store, organize, and retrieve their files with confidence. O-VAULT
                ensures data security through encrypted storage, providing peace of mind and convenient access anytime.
            </p>
            <p>Our system O-VAULT offers a streamlined and secure solution for managing your vital documents and IDs, ensuring easy access and reliable protection.</p>
        </section>
        <h2>Who Can Benefit from Our Website?</h2>
        <section class="who-can-benefit">
            <ul>
                <li>Frequent travelers who need to manage multiple IDs like passports, visas, and travel documents.</li>
                <li>Students and professionals storing certificates, licenses, and important academic records.</li>
                <li>Business owners managing company registration papers, tax documents, and legal records.</li>
                <li>Anyone seeking a secure, digital vault for personal documents like birth certificates and insurance policies.</li>
            </ul>
        </section>
    </div>
    <section class="cta">
        <h2>Ready to Secure Your Documents?</h2>
        <a href="dashboard.php" class="cta-btn">START</a>
    </section>
</body>

</html>
