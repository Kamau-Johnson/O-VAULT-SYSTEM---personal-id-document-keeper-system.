<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "test_db";
$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if (isset($_POST['ids'])) {
    $ids = json_decode($_POST['ids']);
    $placeholders = implode(',', array_fill(0, count($ids), '?'));
    $stmt = $conn->prepare("DELETE FROM ids WHERE id IN ($placeholders)");
    $types = str_repeat('i', count($ids));
    $stmt->bind_param($types, ...$ids);
    
    if ($stmt->execute()) {
        echo "IDs deleted successfully.";
    } else {
        echo "Error deleting IDs: " . $conn->error;
    }
    $stmt->close();
} else {
    echo "No ID IDs provided.";
}

$conn->close();
?>
