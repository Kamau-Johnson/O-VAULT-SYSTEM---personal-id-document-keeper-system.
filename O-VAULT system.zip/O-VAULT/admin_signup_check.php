<?php
session_start();
include "db_conn.php";

if (
    isset($_POST['admin_name']) && isset($_POST['admin_uname']) &&
    isset($_POST['admin_password']) && isset($_POST['admin_re_password']) &&
    isset($_POST['access_code'])
) {

    function validate($data)
    {
        $data = trim($data);
        $data = stripslashes($data);
        $data = htmlspecialchars($data);
        return $data;
    }

    $admin_name = validate($_POST['admin_name']);
    $admin_uname = validate($_POST['admin_uname']);
    $pass = validate($_POST['admin_password']);
    $re_pass = validate($_POST['admin_re_password']);
    $access_code = validate($_POST['access_code']);

    $user_data = 'admin_name=' . $admin_name . '&admin_uname=' . $admin_uname;

    if (empty($admin_name)) {
        header("Location: admin_sign_up.php?error=Admin Name is required&$user_data");
        exit();
    } else if (empty($admin_uname)) {
        header("Location: admin_sign_up.php?error=Admin Username is required&$user_data");
        exit();
    } else if (empty($access_code)) {
        header("Location: admin_sign_up.php?error=Access Code is required&$user_data");
        exit();
    } else if (empty($pass)) {
        header("Location: admin_sign_up.php?error=Password is required&$user_data");
        exit();
    } else if (empty($re_pass)) {
        header("Location: admin_sign_up.php?error=Re Password is required&$user_data");
        exit();
    } else if ($pass !== $re_pass) {
        header("Location: admin_sign_up.php?error=Passwords do not match&$user_data");
        exit();
    } else {
        $pass = md5($pass);
        $sql = "SELECT * FROM admin_users WHERE admin_username='$admin_uname'";
        $result = mysqli_query($conn, $sql);

        if (mysqli_num_rows($result) > 0) {
            header("Location: admin_sign_up.php?error=Username already taken&$user_data");
            exit();
        } else {
            $sql2 = "INSERT INTO admin_users(admin_name, admin_username, admin_password, access_code) 
                     VALUES('$admin_name', '$admin_uname', '$pass', '$access_code')";
            $result2 = mysqli_query($conn, $sql2);
            if ($result2) {
                $_SESSION['success_message'] = "Admin registered successfully!";
                header("Location: admin_login.php");
                exit();
            } else {
                header("Location: admin_sign_up.php?error=Unknown error occurred&$user_data");
                exit();
            }
        }
    }
} else {
    header("Location: admin_sign_up.php");
    exit();
}
