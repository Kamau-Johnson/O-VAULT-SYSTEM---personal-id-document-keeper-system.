<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>LOGIN</title>
    <link rel="stylesheet" href="style.css.css"> <!-- Link to external CSS -->
    <style>
        /* Admin button styling, optimized for compact width */
        .admin-btn {
            position: absolute;
            top: 40px;
            right: 95px;
            padding: 10px 15px;
            /* Small padding for compactness */
            width: auto;
            /* Ensures button width fits the text only */
            background-color: blue;
            color: whitesmoke;
            border: none;
            border-radius: 5px;
            font-size: 14px;
            font-weight: bold;
            cursor: pointer;
            transition: background-color 0.25s;
            box-sizing: border-box;
        }

        .admin-btn:hover {
            background-color: cyan;
            color: black;
        }
    </style>
    <script>
        function checkAdminCode() {
            var code = prompt("Enter Admin Code:");
            if (code === "0464") {
                window.location.href = 'admin_login.php';
            } else {
                alert("Incorrect code. Access denied.");
            }
        }
    </script>
</head>

<body>
    <!-- Admin Button -->
    <button onclick="checkAdminCode()" class="admin-btn">Admin</button>

    <div class="background">
        <form action="login.php" method="post" class="form-container">
            <h2>LOGIN</h2>
            <?php if (isset($_GET['error'])) { ?>
                <p class="error"><?php echo $_GET['error']; ?></p>
            <?php } ?>
            <label for="uname">User Name</label>
            <input type="text" id="uname" name="uname" placeholder="User Name" required><br>

            <label for="password">Password</label>
            <input type="password" id="password" name="password" placeholder="Password" required><br>

            <button type="submit">Login</button>
            <div class="signup-link">
                <a href="signup.php">Create an account</a>
            </div>
        </form>
    </div>
</body>

</html>
