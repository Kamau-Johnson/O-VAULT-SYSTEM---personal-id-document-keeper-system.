<?php
// Enable error reporting for debugging
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "test_db";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Retrieve the user ID dynamically from the query string
$userId = isset($_GET['user_id']) ? intval($_GET['user_id']) : 0;

$sql = "SELECT content_type, data FROM profile_pics WHERE user_id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $userId);
$stmt->execute();
$stmt->store_result();
$stmt->bind_result($content_type, $data);
$stmt->fetch();

if ($stmt->num_rows > 0) {
    header("Content-Type: " . $content_type);
    echo $data;
} else {
    // Provide a default image or handle missing image scenario
    header("Content-Type: image/png");
    echo file_get_contents('default_profile_pic.png'); // Make sure you have a default image
}

$stmt->close();
$conn->close();
