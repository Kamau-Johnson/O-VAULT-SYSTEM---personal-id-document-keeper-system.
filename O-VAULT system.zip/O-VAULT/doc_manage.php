<?php
session_start();
if (!isset($_SESSION['user_name'])) {
    header("Location: index.php");
    exit();
}

// Database connection
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "test_db";
$conn = new mysqli($servername, $username, $password, $dbname);

// Check if the connection is successful
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Fetch documents from the database
$documents = $conn->query("SELECT * FROM documents");

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Documents</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
        }

        .header {
            background-color: #007bff;
            color: white;
            padding: 22px;
            display: flex;
            justify-content: center; /* Center the title */
            align-items: center;
        }

        .header .back-button {
            position: absolute;
            left: 15px; /* Place it on the left side */
            background-color: #4CAF50;
            color: white;
            text-decoration: none;
            padding: 10px 15px;
            border-radius: 5px;
        }

        .header .back-button:hover {
            background-color: #45a049;
        }

        .search-container {
            display: flex;
            justify-content: center;
            margin: 20px 0;
        }

        .search-container input {
            padding: 10px;
            width: 300px;
            font-size: 16px;
            border: 1px solid #ccc;
            border-radius: 5px;
        }

        /* New Delete Button Styles */
        .delete-btn {
            position: absolute;
            top: 135px; /* Adjust based on where you want it below the O-VAULT */
            right: 40px;
            background-color: black;
            color: yellowgreen;
            border: none;
            padding: 10px 20px;
            font-size: 16px;
            border-radius: 5px;
            cursor: pointer;
            transition: background-color 0.3s ease, box-shadow 0.3s ease;
        }

        .delete-btn:hover {
            background-color: white;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
        }

        .container {
            max-width: 1200px;
            margin: 20px auto;
            padding: 0 15px;
        }

        h3 {
            font-size: 24px;
            color: #333;
            margin-top: 30px;
            border-bottom: 2px solid #ddd;
            padding-bottom: 10px;
        }

        .grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(280px, 1fr));
            gap: 20px;
            margin-top: 20px;
        }

        .card {
            background-color: #fff;
            padding: 15px;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            transition: box-shadow 0.3s ease;
        }

        .card:hover {
            box-shadow: 0 8px 16px rgba(0, 0, 0, 0.2);
        }

        .card h4 {
            font-size: 18px;
            color: #333;
            margin-bottom: 10px;
        }

        .card p {
            font-size: 14px;
            color: #666;
            margin: 5px 0;
        }

        @media (max-width: 768px) {
            .grid {
                grid-template-columns: repeat(auto-fill, minmax(250px, 1fr));
            }

            .card {
                padding: 10px;
            }

            .btn-primary {
                font-size: 14px;
                padding: 8px 12px;
            }

            .delete-btn {
                font-size: 14px;
                padding: 8px 16px;
            }
        }
    </style>
</head>
<body>

<header class="header">
    <a href="dashboard.php" class="back-button">Back</a> <!-- Back button on the left -->
    <h2>Manage Documents</h2> <!-- Title remains centered -->
</header>

<div class="search-container">
    <input type="text" id="search-input" placeholder="Search by document name...">
</div>

<div class="container">
    <h3>Documents</h3>
    <form id="delete-form">
        <div class="grid" id="document-grid">
            <?php if ($documents->num_rows > 0): ?>
                <?php while ($document = $documents->fetch_assoc()) { ?>
                    <div class="card" data-name="<?php echo htmlspecialchars($document['document_name'] ?? 'No Name'); ?>">
                        <input type="checkbox" class="document-checkbox" data-id="<?php echo $document['id']; ?>" />
                        <h4>Name: <?php echo htmlspecialchars($document['document_name'] ?? 'No Name'); ?></h4>
                        <p><strong>Uploaded on:</strong> <?php echo isset($document['upload_date']) ? date('M d, Y', strtotime($document['upload_date'])) : 'N/A'; ?></p>
                    </div>
                <?php } ?>
            <?php else: ?>
                <p>No documents found.</p>
            <?php endif; ?>
        </div>

        <button type="button" class="delete-btn" id="delete-button">Delete</button>
    </form>
</div>

<script>
    // Handle Delete button click
    document.getElementById('delete-button').addEventListener('click', function() {
        // Get all checked checkboxes
        const selectedDocuments = [];
        document.querySelectorAll('.document-checkbox:checked').forEach(function(checkbox) {
            selectedDocuments.push(checkbox.getAttribute('data-id'));
        });

        // If no document is selected, show an alert
        if (selectedDocuments.length === 0) {
            alert('Please select at least one document to delete.');
            return;
        }

        // Make an AJAX request to delete selected documents
        const xhr = new XMLHttpRequest();
        xhr.open('POST', 'delete_documents.php', true);
        xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
        xhr.onload = function() {
            if (xhr.status === 200) {
                // If successful, reload the page or remove deleted items from UI
                alert('Documents deleted successfully.');
                location.reload();  // Reload the page to reflect the changes
            } else {
                alert('Error deleting documents: ' + xhr.responseText);
            }
        };

        // Send selected document IDs to delete_documents.php
        xhr.send('ids=' + JSON.stringify(selectedDocuments));
    });

    // Handle search input
    document.getElementById('search-input').addEventListener('input', function() {
        const query = this.value.toLowerCase();
        const documents = document.querySelectorAll('.card');

        documents.forEach(function(document) {
            const name = document.getAttribute('data-name').toLowerCase();
            if (name.includes(query)) {
                document.style.display = 'block';
            } else {
                document.style.display = 'none';
            }
        });
    });
</script>

</body>
</html>

<?php
// Close the database connection
$conn->close();
?>
