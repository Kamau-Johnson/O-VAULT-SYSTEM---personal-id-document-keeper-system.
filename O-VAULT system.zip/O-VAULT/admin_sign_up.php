<!DOCTYPE html>
<html>

<head>
    <title>ADMIN SIGN UP</title>
    <link rel="stylesheet" type="text/css" href="admin_sign_up and login.css">
</head>

<body>
    <div class="background">
        <form action="admin_signup_check.php" method="post" class="form-container">
            <h2>ADMIN SIGN UP</h2>
            <?php if (isset($_GET['error'])) { ?>
                <p class="error"><?php echo $_GET['error']; ?></p>
            <?php } ?>
            <?php if (isset($_GET['success'])) { ?>
                <p class="success"><?php echo $_GET['success']; ?></p>
            <?php } ?>

            <label>Admin Name</label>
            <input type="text" name="admin_name" placeholder="Admin Name"
                value="<?php echo isset($_GET['admin_name']) ? $_GET['admin_name'] : ''; ?>"><br>

            <label>Admin Username</label>
            <input type="text" name="admin_uname" placeholder="Admin Username"
                value="<?php echo isset($_GET['admin_uname']) ? $_GET['admin_uname'] : ''; ?>"><br>

            <label>Access Code</label>
            <input type="text" name="access_code" placeholder="Access Code"><br>

            <label>Password</label>
            <input type="password" name="admin_password" placeholder="Password"><br>

            <label>Re Password</label>
            <input type="password" name="admin_re_password" placeholder="Re-enter Password"><br>

            <button type="submit">Register as Admin</button>
            <div class="ca">
                <a href="admin_login.php">Already have an admin account?</a>
            </div>
        </form>
    </div>
</body>

</html>