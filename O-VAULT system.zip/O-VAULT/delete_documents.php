<?php
// Database connection
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "test_db";
$conn = new mysqli($servername, $username, $password, $dbname);

// Check if the connection is successful
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Check if 'ids' is passed via POST
if (isset($_POST['ids'])) {
    $ids = json_decode($_POST['ids']);  // Decode the JSON array of IDs

    // Prepare the DELETE query
    $placeholders = implode(',', array_fill(0, count($ids), '?'));
    $stmt = $conn->prepare("DELETE FROM documents WHERE id IN ($placeholders)");

    // Bind parameters dynamically based on the number of IDs
    $types = str_repeat('i', count($ids));  // 'i' stands for integer
    $stmt->bind_param($types, ...$ids);

    if ($stmt->execute()) {
        echo "Documents deleted successfully.";
    } else {
        echo "Error deleting documents: " . $conn->error;
    }

    $stmt->close();
} else {
    echo "No document IDs provided.";
}

$conn->close();
?>
