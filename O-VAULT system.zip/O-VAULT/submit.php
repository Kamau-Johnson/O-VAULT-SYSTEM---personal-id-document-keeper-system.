<?php
session_start();
include "db_conn.php"; // Ensure your database connection is established

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = mysqli_real_escape_string($conn, $_POST['name']);
    $email = mysqli_real_escape_string($conn, $_POST['email']);
    $subject = mysqli_real_escape_string($conn, $_POST['subject']);
    $message = mysqli_real_escape_string($conn, $_POST['message']);

    if (isset($_FILES['image']) && $_FILES['image']['error'] == 0) {
        $image = $_FILES['image'];
        $imageName = $image['name'];
        $imageTmpName = $image['tmp_name'];
        $imageSize = $image['size'];
        $imageError = $image['error'];
        $imageType = $image['type'];

        $imageExt = explode('.', $imageName);
        $imageActualExt = strtolower(end($imageExt));

        $allowed = array('jpg', 'jpeg', 'png');

        if (in_array($imageActualExt, $allowed)) {
            if ($imageError === 0) {
                if ($imageSize < 5000000) { // Limit size to 5MB
                    $imageNameNew = uniqid('', true) . "." . $imageActualExt;
                    $imageDestination = 'uploads/' . $imageNameNew;
                    move_uploaded_file($imageTmpName, $imageDestination);
                } else {
                    echo "Your image is too big!";
                    exit();
                }
            } else {
                echo "There was an error uploading your image!";
                exit();
            }
        } else {
            echo "You cannot upload files of this type!";
            exit();
        }
    } else {
        $imageDestination = NULL;
    }

    $sql = "INSERT INTO contacts (name, email, subject, message, image) VALUES ('$name', '$email', '$subject', '$message', '$imageDestination')";
    if (mysqli_query($conn, $sql)) {
        echo "Contact form submitted successfully!";
    } else {
        echo "Error: " . $sql . "<br>" . mysqli_error($conn);
    }
}
