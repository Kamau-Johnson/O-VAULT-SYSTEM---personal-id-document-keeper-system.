<?php
session_start();
if (!isset($_SESSION['user_name'])) {
    header("Location: index.php");
    exit();
}

// Database connection
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "test_db";
$conn = new mysqli($servername, $username, $password, $dbname);

// Check if the connection is successful
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Fetch documents and IDs from the database
$documents = $conn->query("SELECT * FROM documents");
$ids = $conn->query("SELECT * FROM ids");
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>View All Documents & IDs</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
        }

        /* Header Styling */
        .header {
            background-color: #007bff;
            color: white;
            padding: 22px;
            display: flex;
            justify-content: center;
            align-items: center;
            position: relative;
        }

        /* Back Button Styling */
        .header .back-button {
            position: absolute;
            left: 15px;
            background-color: #4CAF50;
            color: white;
            text-decoration: none;
            padding: 10px 15px;
            border-radius: 5px;
        }

        .header .back-button:hover {
            background-color: #45a049;
        }

        /* Page Content Styling */
        .container {
            max-width: 1200px;
            margin: 20px auto;
            padding: 0 15px;
        }

        h3 {
            font-size: 24px;
            color: #333;
            margin-top: 30px;
            border-bottom: 2px solid #ddd;
            padding-bottom: 10px;
        }

        .grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(280px, 1fr));
            gap: 20px;
            margin-top: 20px;
        }

        .card {
            background-color: #fff;
            padding: 15px;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            transition: box-shadow 0.3s ease;
        }

        .card:hover {
            box-shadow: 0 8px 16px rgba(0, 0, 0, 0.2);
        }

        .card h4 {
            font-size: 18px;
            color: #333;
            margin-bottom: 10px;
        }

        .card p {
            font-size: 14px;
            color: #666;
            margin: 5px 0;
        }

        /* Responsive Design */
        @media (max-width: 768px) {
            .grid {
                grid-template-columns: repeat(auto-fill, minmax(250px, 1fr));
            }

            .card {
                padding: 10px;
            }

            .btn-primary {
                font-size: 14px;
                padding: 8px 12px;
            }
        }
    </style>
</head>
<body>

<header class="header">
    <a href="dashboard.php" class="back-button">Back</a>
    <h2>All Documents & IDs</h2>
</header>

<div class="container">
    <!-- Documents Section -->
    <h3>Documents</h3>
    <div class="grid">
        <?php if ($documents->num_rows > 0): ?>
            <?php while ($document = $documents->fetch_assoc()) { ?>
                <div class="card">
                    <h4>Name: <?php echo htmlspecialchars($document['document_name'] ?? 'No Name'); ?></h4>
                    <p><strong>Uploaded on:</strong> <?php echo isset($document['upload_date']) ? date('M d, Y', strtotime($document['upload_date'])) : 'N/A'; ?></p>
                </div>
            <?php } ?>
        <?php else: ?>
            <p>No documents found.</p>
        <?php endif; ?>
    </div>

    <!-- IDs Section -->
    <h3>Your IDs</h3>
    <div class="grid">
        <?php if ($ids->num_rows > 0): ?>
            <?php while ($id = $ids->fetch_assoc()) { ?>
                <div class="card">
                    <h4>Name: <?php echo htmlspecialchars($id['id_name'] ?? 'No Name'); ?></h4>
                </div>
            <?php } ?>
        <?php else: ?>
            <p>No IDs found.</p>
        <?php endif; ?>
    </div>
</div>

</body>
</html>

<?php
// Close the database connection
$conn->close();
?>
